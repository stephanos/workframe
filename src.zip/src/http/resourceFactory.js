import { ApplicationContext } from '../app';
import { Component, Inject } from '../container';

import Resource from './resource';
import { Resource as ResourceDecorator } from './decorators';


const HANDLE_METHOD_NAME = '__handle';


// function createHandlerChain(handlers) {
//   return async (dispatcher, request, response) => {
//     let body = undefined;
//     let result;
//     const item = handlers[i];
//     const next = async (dispatcher, request, response) => {
//       result = createHandlerChain(handlers.slice(0, 1))
//     };
//     const result = await item.handler[HANDLE_METHOD_NAME](dispatcher, request, response, item.params, next);
//     return body;
//   };
// }

/* eslint no-param-reassign:0 */
function createRootHandler(handlers) {
  return async (dispatcher, request, response) => {
    const createHandlerChain = async (list) => {
      if (list.length === 0) {
        return;
      }

      const item = list[0];
      const next = async () => {
        const result = await createHandlerChain(list.slice(0, list.length - 1));
        if (result !== undefined) {
          console.log(result);
          response.body = result;
        }
      };

      const result = await item.handler[HANDLE_METHOD_NAME](dispatcher, request, response, item.params, next);
      if (result !== undefined) {
        console.log(result);
        response.body = result;
      }
    };

    return createHandlerChain(handlers);
  };
}


@Component()
class ResourceFactory {

  @Inject(ApplicationContext)
  appContext;


  create(url, filters, controllerFactory): Array<Resource> {
    const resources = [];
    const controllerComp = this.appContext.getComponentByFactory(controllerFactory);
    const controller = this.appContext.createComponent(controllerComp);

    controllerComp.decorations
      .filter((dec) => dec.type === ResourceDecorator)
      .forEach((resourceDec) => {
        const handlers = filters.slice();
        const methodName = `__${resourceDec.target.name}`; // TODO: call via dispatcher
        handlers.push({
          handler: {
            [HANDLE_METHOD_NAME]: controller[methodName].bind(controller),
          },
        });

        const rootHandler = createRootHandler(handlers);
        const httpMethod = resourceDec.parameters[0];
        const httpPath = url + (resourceDec.parameters[1] || '');
        resources.push(new Resource(rootHandler, httpMethod, httpPath));
      });

    return resources;
  }
}


export default ResourceFactory;
