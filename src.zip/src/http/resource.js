class Resource {

  constructor(handler, method, path) {
    this.handler = handler;
    this.method = method;
    this.path = path;
  }
}


export default Resource;
