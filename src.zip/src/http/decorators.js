export function Resource() {
  return () => {};
}
