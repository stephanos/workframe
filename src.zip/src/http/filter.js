class Filter {

  constructor(handler, params) {
    this.handler = handler;
    this.params = params;
  }
}


export default Filter;
