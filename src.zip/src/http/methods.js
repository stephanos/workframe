const Methods = {
  DELETE: 'DELETE',
  GET: 'GET',
  PATCH: 'PATCH',
  PUT: 'PUT',
  POST: 'POST',
};


export default Methods;
