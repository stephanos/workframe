class FilterComponentType {

  name = 'Filter';
}


export default FilterComponentType;
