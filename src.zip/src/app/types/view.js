class ViewComponentType {

  name = 'View';
}


export default ViewComponentType;
