class ProcessorComponentType {

  name = 'Processor';
}


export default ProcessorComponentType;
