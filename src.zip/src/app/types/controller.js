class ControllerComponentType {

  name = 'Controller';
}


export default ControllerComponentType;
