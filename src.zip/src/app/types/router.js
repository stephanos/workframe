class RouterComponentType {

  name = 'Router';
}


export default RouterComponentType;
