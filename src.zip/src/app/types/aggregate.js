class AggregateComponentType {

  name = 'Aggregate';
}


export default AggregateComponentType;
