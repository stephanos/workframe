class AccessorComponentType {

  name = 'Accessor';
}


export default AccessorComponentType;
