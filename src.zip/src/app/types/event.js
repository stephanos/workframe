class EventComponentType {

  name = 'Event';
}


export default EventComponentType;
