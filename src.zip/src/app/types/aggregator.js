class AggregatorComponentType {

  name = 'Aggregator';
}


export default AggregatorComponentType;
