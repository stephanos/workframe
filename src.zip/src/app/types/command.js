class CommandComponentType {

  name = 'Command';
}


export default CommandComponentType;
