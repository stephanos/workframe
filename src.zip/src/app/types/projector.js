class ProjectorComponentType {

  name = 'Projector';
}


export default ProjectorComponentType;
