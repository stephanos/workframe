class EventStream {

  aggregateContext;
  aggregateName;
  aggregateId;
  aggregateRevision;

  events;
}


export default EventStream;
