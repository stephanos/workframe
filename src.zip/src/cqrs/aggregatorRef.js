/* @flow */


class AggregatorRef {
  context: string;
  name: string;
  id: string;
  rev: ?string;
}


export default AggregatorRef;
