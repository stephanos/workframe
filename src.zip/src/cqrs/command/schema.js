class Command {
  id;
  name;
  version;
  aggregate;
  payload;
}


export default Command;
