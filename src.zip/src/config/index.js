import Config from './config';

export default Config;
