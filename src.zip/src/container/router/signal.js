// class Signal {
//
//   constructor(actor, context, model) {
//     this.actor = actor;
//     this.context = context;
//     this.model = model;
//   }
// }
//
//
// export default Signal;
