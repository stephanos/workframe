import Router from './router';

export default Router;
