export function OnStart() {
  return () => {};
}

export function OnStop() {
  return () => {};
}
