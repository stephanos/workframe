class ProjectorComponentType {

  static typeName = 'Projector';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default ProjectorComponentType;
