class CommandComponentType {

  static typeName = 'Command';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default CommandComponentType;
