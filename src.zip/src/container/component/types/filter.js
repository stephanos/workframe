class FilterComponentType {

  static typeName = 'Filter';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default FilterComponentType;
