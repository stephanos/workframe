class QueryComponentType {

  static typeName = 'Query';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default QueryComponentType;
