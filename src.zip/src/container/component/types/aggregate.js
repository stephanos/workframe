class AggregateComponentType {

  static typeName = 'Aggregate';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default AggregateComponentType;
