class ViewComponentType {

  static typeName = 'View';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default ViewComponentType;
