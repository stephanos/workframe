class EventComponentType {

  static typeName = 'Event';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default EventComponentType;
