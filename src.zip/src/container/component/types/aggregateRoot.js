class AggregateRootComponentType {

  static typeName = 'AggregateRoot';
  static injectTypeWhitelist = [];

  static verify() {
  }
}


export default AggregateRootComponentType;
