class SystemComponentType {

  static typeName = 'System';
  static injectTypeWhitelist = ['State'];

  static verify() {
  }
}


export default SystemComponentType;
