/* eslint-disable */

export class X {};
export class Y {};
export default 'Z';
