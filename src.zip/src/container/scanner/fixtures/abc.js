/* eslint-disable */

class B {
}

class C {
}

export const A = 'A';
export default B;
