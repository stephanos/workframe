const relations = {
  DEPENDS: 'dependsOn',
};


export default relations;
