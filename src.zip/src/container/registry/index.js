import Registry from './registry';
import Inject from './decorator';


export default Registry;
export {
  Inject,
};
