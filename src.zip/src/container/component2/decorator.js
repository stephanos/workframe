export default function Component() {
  return () => {};
}
