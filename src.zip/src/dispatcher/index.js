import DispatcherFactory from './factory';

export default DispatcherFactory;
