class Journal {

  add() {
    // TODO
  }
}


export default Journal;
