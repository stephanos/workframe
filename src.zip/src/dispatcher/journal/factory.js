import Journal from './journal';


class JournalFactory {

  create() {
    return new Journal(); // TODO
  }
}


export default JournalFactory;
