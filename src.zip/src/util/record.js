function Record() {
  return () => {};
}

class RecordBase {}
Record.Base = RecordBase;


export default Record;
